===================
=Less Tedious Fade=
===================

Places a "Mysterious Tome" near the start of the Fade portion of the "Broken Circle" quest, 
after the sloth demon puts the player to sleep. Reading it grants all four 
shapeshifting forms immediately.

That way you won't have to backtrack every time you learn a new form.

You'll find it right after you learn the Mouse form, next to the first Mouse Hole.

Please report any problems by commenting or starting a discussion on the project:

http://social.bioware.com/project/2072/

That's also where to find the latest version.


-------------
INSTALLATION: 
-------------

In your C:\Games\Dragon Age\bin_ship directory (if you installed the game to your games
folder, your installation path may vary), there should be a file called daupdater.exe.

Run that file.
Click "Select DAZIPs."
Select "LessTediousFade.dazip" from wherever you saved it.
Click on it on the list.
Click "Install Selected."
When complete (it won't take long) exit the program.

Once in the game, visit "Installed Content" and ensure the mod's box is checked.